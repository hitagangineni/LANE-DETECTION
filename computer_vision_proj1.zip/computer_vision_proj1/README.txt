INSTRUCTIONS TO EXECUTE THE PROGRAM:-

python3 stop_lane_final.py -folder [test_images_folder]

OUTPUT:-

The program prints total number of lane lines detected for all the images in the test folder. The program also saves the output of the detected lanes in the 
image in the executing directory as outputi, where i = 0 initially and incremented each time a lane line is detected in the image. Stop signs if detected in the image
are stored as stop_sign_outputi where i = 0 initially and is incremented each time a stop sign is detected in the image. 

The Results of lane detection for the test images provided are stored in the folder Lane_Output_Test.
The Results of stop sign detection are stored in Stop_Sign_Test_Output folder.
test_images is a folder containing the test images for the program.

PACKAGES USED:-
cv2
numpy
math
matplotlib
argparse
os
sys
random
