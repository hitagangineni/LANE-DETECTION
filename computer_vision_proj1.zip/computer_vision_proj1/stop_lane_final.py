import cv2
import numpy as np
from math import sin, cos
import matplotlib.pyplot as plt
import argparse
import sys
import os
from os import listdir
from os.path import isfile
from os.path import join
import random as rng
import math

#Return True hough lines detected in a frame in the form of rho and theta, the polar coordinates are then converted to cartesian coordinates and then lines are drawn
def get_true_hough_lines(image, og):
    #The height and width of the image
    r, c = image.shape[:2]
    lines = np.array([])
    #Lines 
    lines = cv2.HoughLines(image, 1, math.pi / 180, 100,)
    #Add lines of certin slope ranges
    range_slopes = []
    lines_drawn = 0
    #If there are no lane lines in the image 
    if lines is None:
        return 
    #For lane in lanes return polar coordinates and convert it into cartesian coordinates if the lanes are horizontal skip those lines
    #Consider only the lines whise slope is greater than 3
    for line in lines:
        rho, theta = line.squeeze()
        a = math.cos(theta)
        b = math.sin(theta)
        x0 = a * rho
        y0 = b * rho
        px = int(math.sqrt(r ** 2 + c ** 2))
        startPoint = (int(x0 - px * b), int(y0 + px * a))
        endPoint = (int(x0 + px * b), int(y0 - px * a))     
        dx = (startPoint[0] - endPoint[0])
        dy = (startPoint[1] - endPoint[1])
        if dx == 0:
            continue
        slope = dy/dx
        skip_line = abs(slope) > 3 or False
        for low, high in range_slopes:
            if low <= slope <= high:
                skip_line = True
                break
                
        range_slopes.append((slope - 1/4, slope + 1/4))
        if skip_line:
           continue
        else:
            lines_drawn += 1

        #Change thickness of the line based on r
        th = 3
        if r > 2000:
            th = 35
        elif r > 1000:
            th = 10
        elif r > 400:
            th = 7
       
        color = [rng.randint(0, 125) for _ in range(3)]
        cv2.line(og, startPoint, endPoint, color, thickness=th)
    
    
    return lines_drawn,og

def detect_stop_sign(image):

    #Convert an image to hsv
    img_hsv=cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    
    # Create a mask 0 with the values
    lower_red_mask = np.array([0,70,50])
    upper_red_mask = np.array([10,255,255])
    mask0 = cv2.inRange(img_hsv, lower_red_mask, upper_red_mask)

    # Create a mask 1 with the values
    lower_red_mask = np.array([170,70,50])
    upper_red_mask = np.array([180,255,255])
    mask1 = cv2.inRange(img_hsv, lower_red_mask, upper_red_mask)

    # join mask0 and mask1
    mask_new = mask0+mask1
    #Create a resultant image taking the bitwise and of the masks
    res = cv2.bitwise_and(image, image, mask = mask_new)
    #Remove noise in the image by gaussian blur
    res = cv2.GaussianBlur(res, (5, 5), 0)
    #Convert the image to gray scale
    gray = cv2.cvtColor(res, cv2.COLOR_BGR2GRAY)
    #Apply thresolding to the image
    gray = cv2.threshold(gray, 20, 255, cv2.THRESH_BINARY)[1]
    #Draw contours to the image
    contours, hierarchy = cv2.findContours(gray, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    max_circle = image.copy()
    #Create a circle with maximum radius
    max_radius = max(min(image.shape[:2]) * 0.05, 25)
    for contour in contours:
        #Create the circle with minimum enclosing circle
        (x,y),radius = cv2.minEnclosingCircle(contour)
        # Convert center and radius to images
        center = (int(x),int(y))
        radius = int(radius)
        if radius > max_radius:
            total = 1
            whites = 1
            for i, row in enumerate(gray):
                for j, col in enumerate(row):
                    dist = math.sqrt((i-y)**2 + (j-x)**2)
                    if dist <= radius:
                        total += 1
                        whites += 1 if col > 200 else 0
                if whites/total > 0.5:
                    max_circle = image.copy()
                    max_circle = cv2.circle(max_circle,center,radius,(255,0,0),2)
                    max_radius = radius
    #if max_circ and image are not equal draw max_circ, return only image if a stop sign is detected.
    if not np.array_equal(max_circle, image):
        return max_circle
###########################################################################

def runon_image(path) :
    # Create an roi for the image by cropping the image
    image = cv2.imread(path)
    image_c = image.copy()
    h, w = image.shape[:2]
    vertical_crop = h//4
    if h >= 2000:
        vertical_crop = int(h//2)
    elif h >= 1000:
        vertical_crop = int(h//3.5)
    elif h >= 500:
        vertical_crop = int(h//4)
    else:
        vertical_crop = int(h//4)
        
    image = image[vertical_crop:,:]
    og = image
    #Read the image convert it into gray scale 
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    mpv = np.mean(gray)
    th_1 = 0.66 * mpv
    th_2 = 1.33 * mpv
    blur_size = (3, 5)
    if h > 700:
        blur_size = (9, 11)
    #Change the blur size based on the size of the image
    blur = cv2.GaussianBlur(gray, blur_size, 0)
    canny = cv2.Canny(blur, th_1, th_2, L2gradient=True)
    #If there are lanes presrnt in the image
    if (get_true_hough_lines(canny, og) != None):
        l,og_new = get_true_hough_lines(canny, og)
    else:
       l,og_new = None,None
    img_new_stop = detect_stop_sign(image_c)
    return l,og_new,img_new_stop 

def runon_folder(path) :
    files = None
    if(path[-1] != "/"):
        path = path + "/"
        files = [join(path,f) for f in listdir(path) if isfile(join(path,f))]
    all_detections = 0
    c1 = 0
    c2 = 0
    for f in files:
        print(f)
        f_detections,og,img_stop_new = runon_image(f)
        #If the image with lane is present in the image
        if ( og is not None):
                plt.imshow(og)
                plt.show()
                plt.savefig('output'+str(c1)+'.jpeg')
                c1 += 1
                if(f_detections != None):
                    all_detections += f_detections
                else:
                    all_detections = 0
        
        #Save the image with stop sign if the stop sign is present in the image
        if (img_stop_new is not None):
            plt.imshow(cv2.cvtColor(img_stop_new, cv2.COLOR_BGR2RGB))
            plt.show()
            plt.savefig('stop_sign_out'+str(c2)+'.jpeg')
            c2 += 1          
        
    return all_detections

if __name__ == '__main__':
    # command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-folder', help="requires path")
    args = parser.parse_args()
    folder = args.folder
    if folder is None :
        print("Folder path must be given \n Example: python proj1.py -folder images")
        sys.exit()

    if folder is not None :
        all_detections = runon_folder(folder)
        #Print the total number of detections in the folder containing images
        print("total of ", all_detections, " detections")
       
